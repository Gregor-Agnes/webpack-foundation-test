
require('foundation-sites/dist/js/foundation.min.js');
require('./test.scss')

__webpack_public_path__ = "http://localhost:8081/";
$(document).ready(function() {
    console.log('ho chi sack nmin', 'hucklebesrry finn')
})

$(document).foundation()

console.log(__webpack_require__.p)

